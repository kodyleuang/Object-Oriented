package edu.uiowa.cs

// write code for Disability, Person, Alien, Resident, Adult and Minor
// classes here (unit test cases are in the ClassTest file)
// you may need to adjust the run configuration for ClassTest also


