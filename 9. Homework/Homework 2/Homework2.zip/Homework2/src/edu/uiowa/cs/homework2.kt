package edu.uiowa.cs

import java.util.*

// globally acessible list of operators:
//  anywhere in your code you can use an expression like
//      if (mystr in operators)
//  to determine whether mystr is one of the known operators
val operators = listOf("*","/","+","-","%","_", // arithmetic operators,
        // _ is unary (means minus, as in 6 + _3)
        "<",">","==",">=","<=","!=", // comparison operators
        "&&", "||", "!" // logic operators, ! is unary
        )

// Tree class: each object is a tree node
data class Tree(var value:Any, var left:Any, var right:Any)

// uE function calculates for a unary operator
fun uE(op:String,v:Any): Any {
    when (op) {
       "_" -> if (v is Int) return -v
       "!" -> if (v is Boolean) return !v
       }
    throw Error()
    }
// bE function calculates for a binary operator
fun bE(op:String,v1:Any,v2:Any): Any {
    if (v1 is Int && v2 is Int)
        when (op) {
        "*" -> return v1*v2
        // incomplete: you have to write the rest of this
        }
    throw Error()
}

// TreeEval takes a tree and returns a new tree by
// "reducing" the original tree to a single node that
// has no children and a value that is either
// an Int or a Boolean; if the root parameter is
// something like Tree(10,Unit,Unit) then there is
// nothing to reduce, so just return root
fun TreeEval(root:Tree): Tree {
    // you have to write the logic here; the
    // throw Error() is just so it will compile
    throw Error()
}

// TreeBuild takes a list like [*, +, 2, 3, + 4, 5]
// and returns a Pair: the first thing in the Pair
// is a tree, the second thing is a substring of
// the input which is the part of the input not yet
// examined by this call to TreeBuild. For example,
// if the input is [>= 37 92 && < -4 100] then the
// the returned value would be
//   Pair(Tree(">=",37,92),listOf("&&","<",-4,100))
fun TreeBuild(input:List<Any>): Pair<Tree,List<Any>> {
    throw Error()
}

